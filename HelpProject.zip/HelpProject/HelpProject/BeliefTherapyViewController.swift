//
//  ViewController.swift
//  HelpProject
//
//  Created by Rem Wind on 7/27/21.
//

import UIKit

class BeliefTherapyViewController: UIViewController {
    
  var testPVC:TestPVC!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

      }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "PVCSegue" {
            if segue.destination.isKind(of: TestPVC.self) {
                testPVC = (segue.destination as! TestPVC)
            }
        }
    }
 
    
        
        
           
      
        
    
    
    
    }
